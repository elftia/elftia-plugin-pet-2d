/** Secret-free model routing contract; standalone for third-party plugin builds. */
export type HostModelRoleTarget =
  | { kind: 'provider'; providerId: string; model: string }
  | { kind: 'subscription'; target: string; model: string }
  | { kind: 'cli'; model: string };
export type HostModelRoleThinkingLevel = 'none' | 'minimal' | 'low' | 'medium' | 'high' | 'xhigh' | 'max';
export type HostModelRoleBinding =
  | { kind: 'model'; target: HostModelRoleTarget; thinkingLevel?: HostModelRoleThinkingLevel }
  | { kind: 'role'; roleId: string }
  | { kind: 'follow-default-provider' };
export interface HostModelRolesConfig {
  version: 1;
  revision: number;
  assignments: Record<string, HostModelRoleBinding>;
}
export interface HostModelRolesPatch {
  assignments: Record<string, HostModelRoleBinding | null>;
  expectedRevision?: number;
}
export type HostModelRoleResolution =
  | { status: 'ready'; roleId: string; target: HostModelRoleTarget;
      thinkingLevel?: HostModelRoleThinkingLevel; revision: number; source: string; chain: string[] }
  | { status: 'unconfigured' | 'invalid' | 'unavailable'; roleId: string; reason: string;
      revision: number; chain: string[] };
