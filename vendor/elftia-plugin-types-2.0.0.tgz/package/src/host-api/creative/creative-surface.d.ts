import type { HostComponentType } from '../_shared';

import type { CreativeBoardTarget } from './creative-board';
import type { CreativeSemanticRef } from './creative-semantic-board';

export interface CreativeBoardSemanticNodeIntent {
  creativeProjectId: string;
  /** @deprecated Unused: the canvas is project-scoped, not board-scoped. */
  boardId: string;
  ref: CreativeSemanticRef;
}

/** Opens a scoped draft; never starts a generation job. */
export interface CreativeBoardGenerationIntent {
  creativeProjectId: string;
  /** @deprecated Unused: the canvas is project-scoped, not board-scoped. */
  boardId: string;
  groupId: string;
  groupKind: 'character' | 'scene';
  mediaType: 'image' | 'video';
}

/** A UI intent about a fixed project asset version; never execution authority. */
export interface CreativeBoardNodeIntent {
  intent: 'inspect' | 'regenerate';
  creativeProjectId: string;
  /** @deprecated Unused: the canvas is project-scoped, not board-scoped. */
  boardId: string;
  assetId: string;
  versionId: string;
}

/**
 * Props of the creative-project canvas surface.
 *
 * The surface renders the HOST's one canvas — the same `CanvasPanel` the
 * `canvas` workspace view uses (Excalidraw editing, generator tools, media
 * import, node flow, debounced autosave). There is no plugin-side board model
 * and no second scene store: the host resolves which scene to show from the
 * ACTIVE session's creative-project binding, so every session of a project
 * shares one canvas and a plugin can never name another project's scene.
 *
 * `target` is retained only so plugins built against Host API ≤1.11x keep
 * compiling; the host ignores it (the board no longer exists) and the scene is
 * chosen from the session, never from a caller-supplied id.
 *
 * @deprecated `target`, `onNodeIntent`, `onSemanticNodeIntent` and
 * `onGenerationIntent` are inert — canvas interactions are driven by the canvas
 * IPC, and section accents belong to the canvas itself.
 */
export interface CreativeBoardSurfaceProps {
  /**
   * The session whose canvas to show. Trusted only AS A SESSION — the host
   * resolves the canvas key from that session's creative-project binding, so
   * this cannot address another project's scene.
   */
  sessionId?: string;
  /** @deprecated Ignored — the host derives the scene from the session. */
  target?: CreativeBoardTarget;
  /** @deprecated Ignored — the board title no longer exists. */
  title?: string;
  className?: string;
  locale?: 'en' | 'zh' | 'ja';
  /** @deprecated Not called — the unified canvas owns node actions. */
  onNodeIntent?: (intent: CreativeBoardNodeIntent) => void;
  /** @deprecated Not called — the unified canvas owns relation inspection. */
  onSemanticNodeIntent?: (intent: CreativeBoardSemanticNodeIntent) => void;
  /** @deprecated Not called — section accents belong to the canvas. */
  onGenerationIntent?: (intent: CreativeBoardGenerationIntent) => void;
}

export interface CreativeSurface {
  Board: HostComponentType<CreativeBoardSurfaceProps>;
  /** @deprecated Always absent on unified hosts. */
  readonly nodeIntents?: true;
  /** @deprecated Always absent on unified hosts. */
  readonly semanticNodeIntents?: true;
  /** @deprecated Always absent on unified hosts. */
  readonly generationIntents?: true;
}
