import type { CreativeMutation } from './creative-project';

export type CreativeLyricsTimelinePreset =
  | 'clean-caption'
  | 'impact-title'
  | 'editorial-paper'
  | 'mono-marquee';
export interface CreativeLyricsTimelineMapping {
  sourceStartSeconds: number;
  timelineStartTicks: number;
  durationTicks: number;
}
export interface CreativeLyricsTimelinePins {
  timing: { documentId: string; revision: number; contentHash: string };
  lyrics: { documentId: string; revision: number; contentHash: string };
  audio: { assetId: string; versionId: string; sha256: string };
}
export interface CreativeLyricsTimelinePayload {
  source: string;
  cues: Array<{
    lineId: string;
    sourceLine: number;
    text: string;
    startTicks: number;
    endTicks: number;
  }>;
  durationTicks: number;
  timelineStartTicks: number;
  language: string;
  starterPreset: CreativeLyricsTimelinePreset;
  seed?: number;
}
export interface CreativeLyricsTimelinePrepare extends CreativeMutation {
  sourceSessionId: string;
  targetId: string;
  trackId: string;
  timing: CreativeLyricsTimelinePins['timing'];
  mapping: CreativeLyricsTimelineMapping;
  language: string;
  starterPreset: CreativeLyricsTimelinePreset;
  seed?: number;
}
export interface CreativeLyricsTimelinePreview {
  planId: string;
  executionHash: string;
  targetId: string;
  trackId: string;
  projectId: string;
  sceneId: string;
  expectedNativeRevision: number;
  locationRevision: number;
  pins: CreativeLyricsTimelinePins;
  payload: CreativeLyricsTimelinePayload;
  candidateHash: string;
  sequenceId: string;
  clipId: string;
  rangeVerification: 'unverified';
}
export interface CreativeLyricsTimelineHandoff extends CreativeLyricsTimelinePreview {
  id: string;
  intentId: string;
  operationId: string;
  registrationOperationId: string;
  sourceSessionId: string;
  mapping: CreativeLyricsTimelineMapping;
  registrationSourceSessionId: string;
  beforeNativeRevision: number;
  nativeRevision: number;
  observedAt: number;
  registration: 'executed' | 'artifact-match';
  lineMappings: Array<{ lineId: string; sourceLine: number; cueId: string }>;
  readbackHash: string;
}
export interface CreativeLyricsTimelineRecovery {
  creativeProjectId: string;
  sourceSessionId: string;
  originalOperationId: string;
}
export type CreativeLyricsTimelineUnavailable = { status: 'prepared-only'; reason: string };
/** Main-half only: trusted confirmation tokens and authoritative evidence never belong to renderer. */
export interface HostCreativeLyricsTimelineLike {
  prepareLyricsTimeline?(
    input: CreativeLyricsTimelinePrepare
  ): Promise<
    { status: 'prepared'; plan: CreativeLyricsTimelinePreview } | CreativeLyricsTimelineUnavailable
  >;
  requestLyricsTimelineConfirmation?(input: {
    planId: string;
  }): Promise<
    | { status: 'approved'; confirmationToken: string; expiresAt: number }
    | { status: 'cancelled'; reason: string }
    | CreativeLyricsTimelineUnavailable
  >;
  executeConfirmedLyricsTimeline?(input: {
    planId: string;
    confirmationToken: string;
  }): Promise<
    | { status: 'recorded'; projectRevision: number; handoff: CreativeLyricsTimelineHandoff }
    | { status: 'needs-reconciliation'; intentId: string; reason: string }
  >;
  readLyricsTimelineRecovery?(input: CreativeLyricsTimelineRecovery): Promise<{
    status: 'recorded' | 'needs-reconciliation';
    intentId: string;
    artifactMatch: boolean;
    reason: string;
  }>;
  recoverLyricsTimeline?(
    input: CreativeLyricsTimelineRecovery & { expectedRevision: number; operationId: string }
  ): Promise<
    | {
        status: 'recorded-artifact-match';
        projectRevision: number;
        intentId: string;
        originalOperationId: string;
        handoff: CreativeLyricsTimelineHandoff;
      }
    | CreativeLyricsTimelineUnavailable
  >;
  listLyricsTimelineHandoffs?(input: {
    creativeProjectId: string;
    sourceSessionId: string;
  }): Promise<CreativeLyricsTimelineHandoff[]>;
}
