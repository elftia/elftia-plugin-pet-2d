import type { CreativeBatchPlanCreate, CreativeBatchPlanTemplate } from './creative-batch-plan';
import type { CreativeCopyCompositionSource } from './creative-composition-production';
import type { CreativeGenerationDestinationContext } from './creative-generation-context';
import type { CreativeCopyReferenceRebindCatalog } from './creative-copy-reference-rebind';

export type * from './creative-copy-reference-rebind';

export interface CreativeCopyReconstructionBlocker {
  sourceNodeId?: string;
  sourceJobId?: string;
  code:
    | 'unsupported-producer'
    | 'unsupported-recipe'
    | 'input-mapping-required'
    | 'input-unavailable'
    | 'output-mapping-required'
    | 'destination-mapping-required'
    | 'destination-unavailable';
  message: string;
}
export interface CreativeCopyInputRequirement {
  sourceAssetId: string;
  sourceVersionId: string;
  mediaKind: 'image' | 'video' | 'audio';
  title: string;
}
export interface CreativeCopyArchiveEntry {
  id: string;
  kind: 'plan' | 'job';
  title: string;
  producer?: string;
  nodeCount: number;
  inputs: CreativeCopyInputRequirement[];
  outputAssetIds: string[];
  /** Historical intent only; draft requires explicit replacement or removal for each node. */
  destinationContexts?: Array<{
    sourceNodeId: string;
    destinationContext: CreativeGenerationDestinationContext;
  }>;
  blockers: CreativeCopyReconstructionBlocker[];
}
export interface CreativeCopyReconstructionCatalog {
  creativeProjectId: string;
  projectRevision: number;
  archiveHash: string;
  entries: CreativeCopyArchiveEntry[];
  /** Presence advertises immediate-copy composition source recovery support. */
  compositionSources?: CreativeCopyCompositionSource[];
  /** Host API 1.109: inert copied references and current fixed-pin availability only. */
  referenceRebinds?: CreativeCopyReferenceRebindCatalog;
}
export interface CreativeCopyReconstructionPinMapping {
  sourceAssetId: string;
  sourceVersionId: string;
  assetId: string;
  versionId: string;
}
export interface CreativeCopyReconstructionDraftInput {
  creativeProjectId: string;
  sourceSessionId: string;
  expectedRevision: number;
  expectedArchiveHash: string;
  source: { kind: 'plan' | 'job'; id: string };
  title?: string;
  inputs: CreativeCopyReconstructionPinMapping[];
  templates?: Array<{ sourceNodeId: string; template: CreativeBatchPlanTemplate }>;
  outputAssets?: Array<{ sourceAssetId: string; assetId: string }>;
  /** Full current target snapshots; null explicitly removes the archived destination intent. */
  destinationContexts?: Array<{
    sourceNodeId: string;
    destinationContext: CreativeGenerationDestinationContext | null;
  }>;
}
export interface CreativeCopyReconstructionPreview {
  creativeProjectId: string;
  projectRevision: number;
  archiveHash: string;
  blockers: CreativeCopyReconstructionBlocker[];
  draft?: Pick<CreativeBatchPlanCreate, 'title' | 'nodes' | 'edges'>;
  nodeMappings: Array<{ sourceNodeId: string; nodeId: string }>;
}
