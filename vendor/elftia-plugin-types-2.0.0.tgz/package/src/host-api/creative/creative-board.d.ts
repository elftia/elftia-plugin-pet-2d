import type { CanvasAppState, CanvasElement, CanvasState } from '@elftia/canvas-core';

import type { CreativeMutation } from './creative-project';
import type { CreativeBoardSemanticProjection } from './creative-semantic-board';
import type { CreativeTimelineAssetRef } from './creative-timeline';

export interface CreativeBoard {
  id: string;
  title: string;
  revision: number;
  scene: CanvasState;
  semanticProjection?: CreativeBoardSemanticProjection;
}
export interface CreativeBoardTarget {
  type: 'creative-project';
  creativeProjectId: string;
  boardId: string;
}
export interface CreativeBoardCreate extends CreativeMutation {
  title: string;
}
export interface CreativeBoardEdit extends CreativeMutation {
  /**
   * @deprecated Ignored. One creative project owns one canvas, so there is no
   * board to address or version. Kept optional so plugins built against Host API
   * ≤1.11x keep compiling; the host projects into the project canvas regardless.
   * The expected revision that actually gates the write is `expectedRevision`.
   */
  boardId?: string;
  /** @deprecated Ignored — see {@link boardId}. */
  expectedBoardRevision?: number;
}
export interface CreativeBoardApply extends CreativeBoardEdit {
  upsertElements?: CanvasElement[];
  removeElementIds?: string[];
  appState?: CanvasAppState;
}
/** Media is resolved by the host from retained project versions, not caller URLs. */
export interface CreativeBoardSyncAssets extends CreativeBoardEdit {}
export interface CreativeBoardProjection {
  assetId: string;
  versionId: string;
  projectionKey: string;
  groupId: string;
  status: 'placed' | 'unplaced';
  elementId?: string;
  reason?: 'needs-media-reference' | 'unsupported-kind';
}
export interface CreativeBoardSyncResult {
  /** @deprecated Always absent: the projection wrote into the project canvas. */
  board?: CreativeBoard;
  projections: CreativeBoardProjection[];
  removedElementIds: string[];
}
/** Projects fixed shot assignments; never selects versions or edits the timeline. */
export interface CreativeBoardSyncShots extends CreativeBoardEdit {}
export interface CreativeBoardShotProjection {
  shotId: string;
  slot: string;
  pin: CreativeTimelineAssetRef;
  projectionKey: string;
  groupId: string;
  status: 'placed' | 'unplaced';
  elementId?: string;
  labelElementId?: string;
  reason?:
    | 'needs-media-reference'
    | 'unsupported-kind'
    | 'unavailable-pin'
    | 'fingerprint-mismatch';
}
export interface CreativeBoardSyncShotsResult {
  /** @deprecated Always absent: the projection wrote into the project canvas. */
  board?: CreativeBoard;
  projections: CreativeBoardShotProjection[];
  removedElementIds: string[];
}
