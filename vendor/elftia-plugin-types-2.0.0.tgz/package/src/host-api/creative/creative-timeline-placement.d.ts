import type { CreativeMutation, CreativeProjectSummary } from './creative-project';
import type {
  CreativeTimelineAssetRef,
  CreativeTimelineAuthorization,
  CreativeTimelineBinding,
  CreativeTimelineExecutionGrant,
} from './creative-timeline';

/** Native integer ticks. Atomically creates one media clip and optionally its matching track. */
export interface CreativeTimelineClipPlacement {
  clipId: string;
  trackId: string;
  /** Fixed UUID trackId; index is within the current scene's same-type tracks, including main. */
  newTrack?: { type: 'video' | 'audio'; index: number };
  startTime: number;
  duration: number;
  trimStart: number;
  trimEnd: number;
}

export interface CreativeTimelinePlaceClipAuthorization extends CreativeTimelineAuthorization {
  /** Injected by trusted Host/bindSession, never selected by a model or renderer. */
  sourceSessionId: string;
  bindingId: string;
  asset: CreativeTimelineAssetRef;
  expectedRocutRevision: number;
  placement: CreativeTimelineClipPlacement;
}

export interface CreativeTimelinePlaceClipGrant extends CreativeTimelineExecutionGrant {
  /** Host-derived retained asset kind; older video-only hosts may omit this field. */
  mediaKind?: 'image' | 'video' | 'audio';
  intentId: string;
  bindingId: string;
  asset: CreativeTimelineAssetRef;
  externalAssetId: string;
  placement: CreativeTimelineClipPlacement;
}

/** Actual readback evidence, not a create-clip request or arbitrary native batch. */
export interface CreativeRocutPlacementReceipt {
  receiptId: string;
  operationId: string;
  kind: 'place-clip';
  projectId: string;
  sceneId: string;
  beforeRevision: number;
  revision: number;
  asset: { externalAssetId: string; sha256: string };
  placement: CreativeTimelineClipPlacement;
  observedAt: number;
  intentId: string;
}

export interface HostCreativeTimelinePlacementLike {
  /** Records matching existing artifacts only; never restores an execution grant. */
  recoverPlaceClip?(
    input: CreativeTimelinePlaceClipRecovery
  ): Promise<CreativeTimelinePlaceClipRecoveryResult>;
  authorizePlaceClip?(
    input: CreativeTimelinePlaceClipAuthorization
  ): Promise<CreativeTimelinePlaceClipGrant>;
  recordPlaceClip?(
    binding: string,
    receipt: CreativeRocutPlacementReceipt
  ): Promise<{ project: CreativeProjectSummary; value: CreativeTimelineBinding[] }>;
}

export interface CreativeTimelinePlaceClipRecovery extends CreativeMutation {
  /** Injected by the current trusted Host session; original session remains provenance only. */
  sourceSessionId: string;
  originalOperationId: string;
}
export interface CreativeTimelinePlaceClipRecoveryResult {
  status: 'recorded-artifact-match';
  originalOperationId: string;
  project: CreativeProjectSummary;
  value: CreativeTimelineBinding[];
}
