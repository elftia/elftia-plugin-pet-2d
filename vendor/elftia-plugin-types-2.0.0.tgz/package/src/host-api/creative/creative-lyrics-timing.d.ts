import type { CreativeDocument } from './creative-document';
import type { CreativeMutation } from './creative-project';
import type { CreativeLyricsTimingMachine } from './creative-lyrics-timing-import';
export type {
  CreativeLyricsTimingAnalysisPin,
  CreativeLyricsTimingSuggestion,
  CreativeLyricsTimingMachine,
  CreativeLyricsTimingImportPreviewInput,
  CreativeLyricsTimingImportPreview,
  CreativeLyricsTimingImport,
} from './creative-lyrics-timing-import';

export interface CreativeLyricsTimingAudio {
  assetId: string;
  versionId: string;
  sha256: string;
}
export interface CreativeLyricsTimingManual {
  startSeconds: number;
  endSeconds: number;
  review: 'draft' | 'confirmed';
}
export interface CreativeLyricsTimingLine {
  lineId: string;
  index: number;
  text: string;
  textHash: string;
  manual?: CreativeLyricsTimingManual;
}
export interface CreativeLyricsTimingContent {
  schema: 'elftia-lyrics-timing/1' | 'elftia-lyrics-timing/2';
  coordinate: 'source-audio-seconds';
  lyrics: { documentId: string; revision: number; contentHash: string; content: string };
  audio: CreativeLyricsTimingAudio;
  lines: CreativeLyricsTimingLine[];
  machine?: CreativeLyricsTimingMachine;
}
export interface CreativeLyricsTimingCreate extends CreativeMutation {
  title: string;
  lyricsDocumentId: string;
  expectedLyricsRevision: number;
  expectedLyricsContentHash: string;
  audio: CreativeLyricsTimingAudio;
}
export interface CreativeLyricsTimingRef {
  creativeProjectId: string;
  documentId: string;
  sourceSessionId?: string;
}
export interface CreativeLyricsTimingWrite extends CreativeMutation {
  documentId: string;
  expectedDocumentRevision: number;
  expectedContentHash: string;
  /** Complete original order. Omitted manual means unassigned, not inferred. */
  lines: Array<{ lineId: string; manual?: CreativeLyricsTimingManual }>;
}
export interface CreativeLyricsTimingRead {
  document: CreativeDocument;
  contentHash: string;
  timing: CreativeLyricsTimingContent;
  status: 'current' | 'stale' | 'unavailable';
  reasons: string[];
  /** Manual review is not an audio decode or trusted duration check. */
  rangeVerification: 'unverified';
  machineStatus?: { status: 'current' | 'stale' | 'unavailable'; reasons: string[] };
}

export interface CreativeLyricsTimingExport extends CreativeLyricsTimingRef {
  expectedDocumentRevision: number;
  expectedContentHash: string;
}
export interface CreativeLyricsTimingLrc {
  lrc: string;
  documentId: string;
  documentRevision: number;
  contentHash: string;
  lyrics: { documentId: string; revision: number; contentHash: string };
  audio: CreativeLyricsTimingAudio;
  rangeVerification: 'unverified';
}
