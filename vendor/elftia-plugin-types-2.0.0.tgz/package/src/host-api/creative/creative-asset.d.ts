import type { CreativeMutation, CreativeProjectSummary } from './creative-project';

export interface CreativeAssetAudioSummary {
  creativeProjectId: string;
  assetId: string;
  versionId: string;
  sha256: string;
}
export type CreativeAssetAudioSummaryResult =
  | { status: 'available'; durationSeconds: number; waveform: number[] }
  | { status: 'unavailable'; reason: string };

export interface CreativeAssetPoster {
  relativePath: string;
  sha256: string;
  sizeBytes: number;
  width: number;
  height: number;
  mimeType: 'image/png';
  sourceSha256: string;
  sourceTime: number;
}

export interface CreativeAssetEnsurePoster extends CreativeMutation {
  assetId: string;
  versionId: string;
  sha256: string;
}

export type CreativeAssetEnsurePosterResult =
  | { status: 'available'; project: CreativeProjectSummary; value: CreativeAsset }
  | { status: 'unavailable'; reason: string };

export interface CreativeAssetVersion {
  /** Hash-bound Host decode observations; transparency is not edge-quality approval. */
  imageFacts?: {
    sourceSha256: string;
    width: number;
    height: number;
    hasAlphaChannel: boolean;
    isOpaque: boolean;
    hasTransparency: boolean;
  };
  /** Inert, hash-bound composition content identity; never production authorization. */
  compositionContent?: {
    schema: 'elftia-composition-content/1';
    compositionId: string;
    compositionDigest: string;
  };
  poster?: CreativeAssetPoster;
  id: string;
  relativePath: string;
  sha256: string;
  sizeBytes: number;
  createdAt: number;
  source: {
    type: 'import' | 'generation' | 'analysis' | 'director' | 'programmatic';
    sourceSessionId?: string;
    runId?: string;
    outputId?: string;
    recipe?: Record<string, unknown>;
  };
}

export interface CreativeAsset {
  id: string;
  title: string;
  kind: 'image' | 'video' | 'audio' | 'model' | 'other';
  revision: number;
  selectedVersionId?: string;
  versions: CreativeAssetVersion[];
  tags: string[];
  archived: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface CreativeAssetRegister extends CreativeMutation {
  assetId?: string;
  title: string;
  kind: CreativeAsset['kind'];
  sourceRelativePath: string;
  expectedSha256?: string;
  source: CreativeAssetVersion['source'];
  tags?: string[];
}

export interface CreativeAssetSelect extends CreativeMutation {
  assetId: string;
  versionId: string;
  expectedAssetRevision: number;
}

export interface CreativeAssetInspect {
  asset: CreativeAsset;
  files: Array<{
    versionId: string;
    status: 'available' | 'missing' | 'changed';
    previewUrl?: string;
    posterStatus?: 'available' | 'missing' | 'changed';
    posterUrl?: string;
  }>;
}
