export interface CreativeProjectSummary {
  creativeProjectId: string;
  /** New structured records require compatible writers; version 9 protects composition content. */
  schemaVersion: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11;
  title: string;
  revision: number;
  createdAt: number;
  updatedAt: number;
  hostProjectId?: string;
}

export interface CreativeProjectLocation {
  creativeProjectId: string;
  root: string;
  locationRevision: number;
  status: 'available' | 'missing';
}

export interface CreativeProjectLocationPreview {
  project: CreativeProjectSummary;
  /** Optional fixed state digest for explicit existing-project registration. */
  stateHash?: string;
  candidateRoot: string;
  state: 'unregistered' | 'current' | 'relinkable' | 'duplicate';
  registeredLocation?: Pick<
    CreativeProjectLocation,
    'creativeProjectId' | 'root' | 'locationRevision'
  >;
}

export interface CreativeMutation {
  creativeProjectId: string;
  expectedRevision: number;
  operationId: string;
  sourceSessionId?: string;
}

export interface CreativeChange {
  revision: number;
  operationId: string;
  changedAt: number;
  sourceSessionId?: string;
  /**
   * `board` is legacy read-only: journals committed before the canvas
   * unification recorded board-scoped changes. New writes use `canvas`.
   */
  entityType:
    | 'project'
    | 'document'
    | 'asset'
    | 'job'
    | 'canvas'
    | 'board'
    | 'timeline'
    | 'shot'
    | 'batch';
  entityIds: string[];
}

export interface CreativeProjectContext {
  project: CreativeProjectSummary;
  location: CreativeProjectLocation;
  sourceSessionId?: string;
}

export interface CreativeEntitySelection {
  creativeProjectId: string;
  entityType: 'document' | 'asset' | 'job';
  entityId: string;
  versionId?: string;
}
