import type { CreativeJobStatus } from './creative-job';
import type { CreativeMutation } from './creative-project';

export interface CreativeBatchEdge {
  prerequisiteJobId: string;
  dependentJobId: string;
}
export interface CreativeBatch {
  id: string;
  title: string;
  jobs: Array<{ jobId: string; requestHash: string }>;
  edges: CreativeBatchEdge[];
  createdAt: number;
  sourceSessionId?: string;
}
export interface CreativeBatchCreate extends CreativeMutation {
  title: string;
  jobs: Array<{ jobId: string; expectedRequestHash: string }>;
  edges: CreativeBatchEdge[];
}
export interface CreativeBatchRef {
  creativeProjectId: string;
  batchId: string;
}
export interface CreativeBatchReadiness {
  batch: CreativeBatch;
  projectRevision: number;
  jobs: Array<{
    jobId: string;
    status: CreativeJobStatus;
    state: 'ready' | 'blocked' | 'reserved' | 'terminal';
    blockers: Array<{ jobId: string; reason: string }>;
  }>;
}
