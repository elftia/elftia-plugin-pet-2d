import type { CreativeMutation } from './creative-project';
import type { CreativeTimelineAssetRef } from './creative-timeline';

export interface CreativeImportRecoveryReference {
  creativeProjectId: string;
  originalOperationId: string;
  intentHash: string;
}

export interface CreativeImportRecoveryView extends CreativeImportRecoveryReference {
  asset: CreativeTimelineAssetRef;
  targetId: string;
  projectId: string;
  sceneId: string;
  expectedRocutRevision: number;
  status: 'unknown' | 'committed' | 'registered';
  reason?: string;
  projectRevision?: number;
  registrationOperationId?: string;
  registrationOutcome?: 'unknown' | 'not-committed';
}

export interface CreativeImportRecoveryRequest
  extends CreativeMutation, CreativeImportRecoveryReference {}

export interface CreativeImportRecoveryResult {
  status: 'recorded' | 'already-recorded' | 'unknown';
  originalOperationId: string;
  intentHash: string;
  projectRevision?: number;
  registrationOperationId?: string;
  registrationOutcome?: 'unknown' | 'not-committed';
  reason?: string;
}

/** Main-only recovery of an original import. No execution grant or supplied receipt. */
export interface HostCreativeImportRecoveryLike {
  listImportRecoveries?(input: {
    creativeProjectId: string;
  }): Promise<CreativeImportRecoveryView[]>;
  inspectImportRecovery?(
    input: CreativeImportRecoveryReference
  ): Promise<CreativeImportRecoveryView>;
  recoverImport?(input: CreativeImportRecoveryRequest): Promise<CreativeImportRecoveryResult>;
}
