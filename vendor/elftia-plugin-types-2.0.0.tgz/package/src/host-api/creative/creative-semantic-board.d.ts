import type { CreativeBoard, CreativeBoardEdit } from './creative-board';

export type CreativeSemanticGroupKind =
  | 'plan'
  | 'song-lyrics'
  | 'character'
  | 'scene'
  | 'shots'
  | 'materials'
  | 'previz'
  | 'selected'
  | 'pending-failed';

interface DocumentPin {
  documentId: string;
  revision: number;
  contentHash: string;
}
interface AssetPin {
  assetId: string;
  versionId: string;
  sha256: string;
}
type SemanticSource =
  | ({ kind: 'asset-version' } & AssetPin)
  | { kind: 'job'; jobId: string; requestHash: string };

/** Read-only relationship snapshots, not media or execution authority. */
export type CreativeSemanticRef =
  | ({ kind: 'document' } & DocumentPin)
  | SemanticSource
  | { kind: 'shot'; shotId: string; revision: number }
  | {
      kind: 'document-purpose';
      purpose: 'character' | 'scene';
      document: DocumentPin;
      source: SemanticSource;
    }
  | { kind: 'shot-assignment'; shotId: string; slot: string; pin: AssetPin }
  | {
      kind: 'shot-intent';
      shot: { shotId: string; revision: number; slot: string };
      source: SemanticSource;
    };

/** Explicit additive projection; never assigns shots, selects versions or executes jobs. */
export interface CreativeBoardSyncSemanticGroups extends CreativeBoardEdit {
  groups?: CreativeSemanticGroupKind[];
  /** Default 32, maximum 100 references in each requested group. */
  limitPerGroup?: number;
  /** Optional Host 1.107 capability; omitted preserves the existing binding. */
  autoSync?: boolean;
}

/** Durable metadata-only projection; never authorizes generation or timeline edits. */
export interface CreativeBoardSemanticProjection {
  version: 1;
  enabled: boolean;
  groups: CreativeSemanticGroupKind[];
  limitPerGroup: number;
  targetRevision: number;
  appliedRevision: number;
}

export interface CreativeBoardSemanticGroupProjection {
  kind: CreativeSemanticGroupKind;
  groupId: string;
  headerElementId: string;
  cardElementIds: string[];
  /** Omitted if the bounded source scan could not determine the complete count. */
  total?: number;
  shown: number;
  truncated: boolean;
  scanLimited: boolean;
}

export interface CreativeBoardSyncSemanticGroupsResult {
  /** @deprecated Always absent: the projection wrote into the project canvas. */
  board?: CreativeBoard;
  groups: CreativeBoardSemanticGroupProjection[];
  removedElementIds: string[];
}
