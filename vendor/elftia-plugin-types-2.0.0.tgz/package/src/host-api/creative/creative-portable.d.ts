export interface CreativeSnapshotExportInput {
  creativeProjectId: string;
  expectedRevision: number;
  sourceSessionId?: string;
}

export interface CreativeSnapshotExportResult {
  format: 'elftia-creative-snapshot/1';
  creativeProjectId: string;
  revision: number;
  relativePath: string;
  sha256: string;
  fileCount: number;
  totalFileBytes: number;
  /** The manifest alone is not a media archive: transfer the whole project directory. */
  copyProjectDirectory: true;
}
