import type { CreativeProjectLocation, CreativeProjectSummary } from './creative-project';

export interface CreativeProjectListQuery {
  cursor?: string;
  limit?: number;
}

export interface CreativeProjectListItem {
  project: CreativeProjectSummary;
  location: CreativeProjectLocation;
  sessionIds: string[];
  lastOpenedAt: number;
  /** Content may be unavailable while the registered identity remains discoverable. */
  contentError?: string;
}

export interface CreativeProjectListPage {
  items: CreativeProjectListItem[];
  nextCursor?: string;
}
