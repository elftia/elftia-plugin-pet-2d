import type { CreativeTimelineAssetRef } from './creative-timeline';
import type { CreativeMutation } from './creative-project';

/** Production route preference, not a claim that an engine is available. */
export type CreativeShotRoute =
  | 'native'
  | 'canvas'
  | 'three'
  | 'hyperframes'
  | 'remotion'
  | 'director'
  | 'external';
export type CreativeShotReviewState = 'draft' | 'needs-review' | 'approved';

/** Seconds on the pinned original audio, never editor ticks or inferred alignment. */
export interface CreativeShotAudioWindow {
  pin: CreativeTimelineAssetRef;
  startSeconds: number;
  endSeconds: number;
}
export interface CreativeShotAssignment {
  slot: string;
  pin: CreativeTimelineAssetRef;
}
export interface CreativeShot {
  /** Read projection only; timing and fixed pins are authored through this timeline. */
  authorBinding?: { timelineId: string; timelineRevision: number; nodeIds: string[] };
  id: string;
  title: string;
  description: string;
  revision: number;
  planDocumentId?: string;
  audioWindow?: CreativeShotAudioWindow;
  route: CreativeShotRoute;
  reviewState: CreativeShotReviewState;
  assignments: CreativeShotAssignment[];
  archived: boolean;
  createdAt: number;
  updatedAt: number;
}
export interface CreativeShotCreate extends CreativeMutation {
  title: string;
  description?: string;
  planDocumentId?: string;
  audioWindow?: CreativeShotAudioWindow;
  route?: CreativeShotRoute;
}
export interface CreativeShotEdit extends CreativeMutation {
  shotId: string;
  expectedShotRevision: number;
}
export interface CreativeShotPatch extends CreativeShotEdit {
  title?: string;
  description?: string;
  planDocumentId?: string | null;
  audioWindow?: CreativeShotAudioWindow | null;
  route?: CreativeShotRoute;
  reviewState?: CreativeShotReviewState;
}
export interface CreativeShotAssignVersion extends CreativeShotEdit {
  slot: string;
  pin: CreativeTimelineAssetRef | null;
}
