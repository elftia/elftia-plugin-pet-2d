import type { CreativeJobAssetRef } from './creative-job';
import type { CreativeMutation, CreativeProjectSummary } from './creative-project';
import type { CreativeRocutExportOptions } from './creative-production';

export interface CreativeCompositionResourceBinding extends CreativeJobAssetRef {
  resourceId: string;
}
export interface CreativeCompositionSourcePin extends CreativeJobAssetRef {
  sha256: string;
  bytes: number;
}
/** Selects retained content from the immediate independent-copy archive, never execution authority. */
export interface CreativeCompositionCopyArchiveSource extends CreativeJobAssetRef {
  expectedArchiveHash: string;
}
export interface CreativeCopyCompositionSource {
  selector: CreativeCompositionCopyArchiveSource;
  compositionId: string;
  compositionDigest: string;
  kind: 'html' | 'remotion';
  title: string;
  sourcePin: CreativeCompositionSourcePin;
  resources: Array<{
    resourceId: string;
    kind:
      | 'image'
      | 'imageSequence'
      | 'font'
      | 'video'
      | 'model'
      | 'environment'
      | 'analysis'
      | 'document'
      | 'source';
    sha256: string;
    bytes: number;
  }>;
}
export interface CreativeCompositionProductionRecipe {
  schema: 'elftia-composition-production/1';
  scope: 'composition';
  targetId: string;
  compositionId: string;
  compositionDigest: string;
  sourcePin: CreativeCompositionSourcePin;
  bindings: Array<CreativeCompositionResourceBinding & { sha256: string; bytes: number }>;
  toolchainFingerprints: Record<string, string>;
  options: CreativeRocutExportOptions;
  outputAssetId?: string;
}
/** Explicitly archives production inputs; does not compile, render or request a job. */
export interface CreativePrepareComposition extends CreativeMutation {
  sourceSessionId: string;
  compositionId: string;
  expectedCompositionDigest: string;
  copyArchiveSource?: CreativeCompositionCopyArchiveSource;
  targetId: string;
  bindings: CreativeCompositionResourceBinding[];
  options: CreativeRocutExportOptions;
  outputAssetId?: string;
}
export type CreativePrepareCompositionResult =
  | {
      status: 'prepared';
      project: CreativeProjectSummary;
      recipe: CreativeCompositionProductionRecipe;
      inputs: CreativeJobAssetRef[];
      sourcePin: CreativeCompositionSourcePin;
    }
  | { status: 'unavailable'; reason: string };
