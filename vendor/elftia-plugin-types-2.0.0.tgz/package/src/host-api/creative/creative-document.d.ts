import type { CreativeMutation } from './creative-project';

export interface CreativeDocument {
  id: string;
  title: string;
  kind: 'plan' | 'lyrics' | 'brief' | 'notes' | 'lyrics-timing';
  purpose?: 'character' | 'scene';
  relativePath: string;
  revision: number;
  contentHash: string;
  archived: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface CreativeDocumentRead {
  document: CreativeDocument;
  content: string;
  contentHash: string;
  externallyModified: boolean;
}

export interface CreativeDocumentCreate extends CreativeMutation {
  purpose?: CreativeDocument['purpose'];
  title: string;
  kind: Exclude<CreativeDocument['kind'], 'lyrics-timing'>;
  content: string;
}

export interface CreativeDocumentWrite extends CreativeMutation {
  /** Omitted preserves the current purpose; null explicitly clears it. */
  purpose?: CreativeDocument['purpose'] | null;
  documentId: string;
  expectedDocumentRevision: number;
  expectedContentHash: string;
  content: string;
}

export interface CreativeDocumentSectionPatch extends Omit<CreativeDocumentWrite, 'content'> {
  heading: string;
  occurrence?: number;
  content: string;
}
