import type {
  CreativeAsset,
  CreativeAssetAudioSummary,
  CreativeAssetAudioSummaryResult,
  CreativeAssetEnsurePoster,
  CreativeAssetEnsurePosterResult,
  CreativeAssetInspect,
  CreativeAssetRegister,
  CreativeAssetSelect,
} from './creative-asset';
import type {
  CreativeBatch,
  CreativeBatchCreate,
  CreativeBatchReadiness,
  CreativeBatchRef,
} from './creative-batch';
import type {
  CreativeBoard,
  CreativeBoardApply,
  CreativeBoardCreate,
  CreativeBoardSyncAssets,
  CreativeBoardSyncResult,
  CreativeBoardSyncShots,
  CreativeBoardSyncShotsResult,
} from './creative-board';
import type {
  CreativeDocument,
  CreativeDocumentCreate,
  CreativeDocumentRead,
  CreativeDocumentSectionPatch,
  CreativeDocumentWrite,
} from './creative-document';
import type {
  CreativeChangesPage,
  CreativeChangesQuery,
  CreativeInspection,
  CreativeInspectQuery,
} from './creative-inspection';
import type { CreativeJob, CreativeJobCancelRequest, CreativeJobRequest } from './creative-job';
import type { CreativeProjectListPage, CreativeProjectListQuery } from './creative-project-list';
import type {
  CreativeSnapshotExportInput,
  CreativeSnapshotExportResult,
} from './creative-portable';
import type {
  CreativeLyricsTimingCreate,
  CreativeLyricsTimingExport,
  CreativeLyricsTimingLrc,
  CreativeLyricsTimingImport,
  CreativeLyricsTimingImportPreview,
  CreativeLyricsTimingImportPreviewInput,
  CreativeLyricsTimingRead,
  CreativeLyricsTimingRef,
  CreativeLyricsTimingWrite,
} from './creative-lyrics-timing';
import type {
  CreativeShot,
  CreativeShotAssignVersion,
  CreativeShotCreate,
  CreativeShotEdit,
  CreativeShotPatch,
} from './creative-shot';
import type {
  CreativeTimelineBinding,
  CreativeTimelineReplacePlan,
  CreativeTimelineReplaceRequest,
} from './creative-timeline';
import type {
  CreativeBoardSyncSemanticGroups,
  CreativeBoardSyncSemanticGroupsResult,
} from './creative-semantic-board';
import type {
  CreativeMutation,
  CreativeProjectContext,
  CreativeProjectLocationPreview,
  CreativeProjectSummary,
} from './creative-project';

export type { CreativeAsset, CreativeAssetVersion } from './creative-asset';
export type { CreativeDocument, CreativeDocumentRead } from './creative-document';
export type { CreativeGenerationDestinationContext } from './creative-generation-context';
export type {
  CreativeEntitySelection,
  CreativeProjectContext,
  CreativeProjectSummary,
} from './creative-project';

export interface CreativeCommitResult<T> {
  project: CreativeProjectSummary;
  value: T;
}
export interface CreativeProjectRef {
  creativeProjectId: string;
}
export interface CreativeAssetEdit extends CreativeMutation {
  assetId: string;
  expectedAssetRevision: number;
}
export interface CreativeDocumentArchive extends CreativeMutation {
  documentId: string;
  expectedDocumentRevision: number;
}
export interface CreativeProjectChanged {
  creativeProjectId: string;
  revision: number;
  operationId: string;
}

export interface CreativeApi {
  mv?: import('./creative-mv').CreativeMvApi;
  /** Registry-backed projects, independent of the presence of chat sessions. */
  listProjects?(input: CreativeProjectListQuery): Promise<CreativeProjectListPage>;
  /** Persist an explicit portable snapshot without exposing SQL or accepting arbitrary paths. */
  exportSnapshot?(input: CreativeSnapshotExportInput): Promise<CreativeSnapshotExportResult>;
  /** Host API 1.108. Read-only journal-backed references; feature-detect the real marker. */
  artifacts?: import('./creative-artifacts').CreativeArtifactsApi;
  /** Additive in Host API 1.96. Immutable plans; no producer execution or scheduler. */
  batchPlans?: {
    /** Host API 1.101: read inert copy provenance without exposing execution receipts. */
    listCopyArchive?(
      input: CreativeProjectRef & { sourceSessionId?: string }
    ): Promise<import('./creative-copy-reconstruction').CreativeCopyReconstructionCatalog | null>;
    /** Produce an editable draft only; saving and execution require separate current actions. */
    draftCopy?(
      input: import('./creative-copy-reconstruction').CreativeCopyReconstructionDraftInput
    ): Promise<import('./creative-copy-reconstruction').CreativeCopyReconstructionPreview>;
    create(
      input: import('./creative-batch-plan').CreativeBatchPlanCreate
    ): Promise<CreativeCommitResult<import('./creative-batch-plan').CreativeBatchPlan>>;
    list(
      input: CreativeProjectRef & { sourceSessionId?: string }
    ): Promise<import('./creative-batch-plan').CreativeBatchPlan[]>;
    get(
      input: import('./creative-batch-plan').CreativeBatchPlanRef
    ): Promise<import('./creative-batch-plan').CreativeBatchPlan>;
    readiness(
      input: import('./creative-batch-plan').CreativeBatchPlanRef
    ): Promise<import('./creative-batch-plan').CreativeBatchPlanReadiness>;
    materialize(
      input: import('./creative-batch-plan').CreativeBatchPlanMaterialize
    ): Promise<CreativeCommitResult<import('./creative-batch-plan').CreativeBatchPlanMaterialized>>;
  };
  /** Additive in Host API 1.94. Groups fixed saved jobs; never dispatches production. */
  batches?: {
    create(input: CreativeBatchCreate): Promise<CreativeCommitResult<CreativeBatch>>;
    list(input: CreativeProjectRef): Promise<CreativeBatch[]>;
    get(input: CreativeBatchRef): Promise<CreativeBatch>;
    readiness(input: CreativeBatchRef): Promise<CreativeBatchReadiness>;
  };
  /** Additive in Host API 1.93; feature-detect on older Hosts. */
  lyricsTiming?: {
    create(input: CreativeLyricsTimingCreate): Promise<CreativeCommitResult<CreativeDocument>>;
    read(input: CreativeLyricsTimingRef): Promise<CreativeLyricsTimingRead>;
    write(input: CreativeLyricsTimingWrite): Promise<CreativeCommitResult<CreativeDocument>>;
    exportLrc(input: CreativeLyricsTimingExport): Promise<CreativeLyricsTimingLrc>;
    /** Host API 1.98. Fixed archived analysis only; preview never writes or runs a tool. */
    previewImport?(
      input: CreativeLyricsTimingImportPreviewInput
    ): Promise<CreativeLyricsTimingImportPreview>;
    /** Persists machine suggestions without changing manual review or the timeline. */
    importAnalysis?(
      input: CreativeLyricsTimingImport
    ): Promise<CreativeCommitResult<CreativeDocument>>;
  };
  previewLocation?(input: { sessionId: string }): Promise<CreativeProjectLocationPreview | null>;
  /** Host API 1.102. Registers verified existing data, never initializes or transfers authority. */
  openExisting?(input: {
    creativeProjectId: string;
    sessionId: string;
    expectedRevision: number;
    expectedStateHash: string;
  }): Promise<CreativeProjectContext>;
  /** Rebinds an existing identity only. No file move, copy, initialization or force adoption. */
  relink?(input: {
    creativeProjectId: string;
    sessionId: string;
    expectedLocationRevision: number;
  }): Promise<CreativeProjectContext>;
  /** Additive in Host API 1.80; probe on older Hosts before using shot records. */
  shots?: {
    list(input: CreativeProjectRef & { includeArchived?: boolean }): Promise<CreativeShot[]>;
    get(input: CreativeProjectRef & { shotId: string }): Promise<CreativeShot>;
    create(input: CreativeShotCreate): Promise<CreativeCommitResult<CreativeShot>>;
    /** Atomically create 1–200 shots with one project revision. */
    createBatch?(
      input: CreativeMutation & {
        shots: Array<Omit<CreativeShotCreate, keyof CreativeMutation>>;
      }
    ): Promise<CreativeCommitResult<CreativeShot[]>>;
    patch(input: CreativeShotPatch): Promise<CreativeCommitResult<CreativeShot>>;
    /** Atomic field/time-window and slot changes; each item carries its shot revision. */
    editBatch?(
      input: CreativeMutation & {
        shots: Array<
          Omit<CreativeShotPatch, keyof CreativeMutation> & {
            assignments?: Array<Pick<CreativeShotAssignVersion, 'slot' | 'pin'>>;
          }
        >;
      }
    ): Promise<CreativeCommitResult<CreativeShot[]>>;
    assignVersion(input: CreativeShotAssignVersion): Promise<CreativeCommitResult<CreativeShot>>;
    archive(input: CreativeShotEdit): Promise<CreativeCommitResult<CreativeShot>>;
  };
  timelines: {
    list(input: CreativeProjectRef): Promise<CreativeTimelineBinding[]>;
    planReplace(input: CreativeTimelineReplaceRequest): Promise<CreativeTimelineReplacePlan>;
  };
  resolveSession(input: { sessionId: string }): Promise<CreativeProjectContext | null>;
  boards: {
    /** Host API 1.106. A real Host marker, not inferred from a transport stub. */
    readonly semanticGroupsVersion?: 1;
    /** Durable automatic projection support, independent of one-time sync. */
    readonly semanticProjectionVersion?: 1;
    // Board CRUD is gone: one creative project owns one canvas, which IS the
    // host canvas the user edits. What remains projects content into it.
    syncAssets(
      input: CreativeBoardSyncAssets
    ): Promise<CreativeCommitResult<CreativeBoardSyncResult>>;
    /** Additive in Host API 1.82; feature-detect on older Hosts. */
    syncShots?(
      input: CreativeBoardSyncShots
    ): Promise<CreativeCommitResult<CreativeBoardSyncShotsResult>>;
    syncSemanticGroups?(
      input: CreativeBoardSyncSemanticGroups
    ): Promise<CreativeCommitResult<CreativeBoardSyncSemanticGroupsResult>>;
  };
  open(input: {
    sessionId: string;
    title?: string;
    expectedLocationRevision?: number;
  }): Promise<CreativeProjectContext>;
  get(input: CreativeProjectRef): Promise<CreativeProjectContext>;
  inspect(input: CreativeProjectRef & CreativeInspectQuery): Promise<CreativeInspection>;
  changes(input: CreativeProjectRef & CreativeChangesQuery): Promise<CreativeChangesPage>;
  documents: {
    list(input: CreativeProjectRef & { includeArchived?: boolean }): Promise<CreativeDocument[]>;
    read(input: CreativeProjectRef & { documentId: string }): Promise<CreativeDocumentRead>;
    create(input: CreativeDocumentCreate): Promise<CreativeCommitResult<CreativeDocument>>;
    write(input: CreativeDocumentWrite): Promise<CreativeCommitResult<CreativeDocument>>;
    patchSection(
      input: CreativeDocumentSectionPatch
    ): Promise<CreativeCommitResult<CreativeDocument>>;
    archive(input: CreativeDocumentArchive): Promise<CreativeCommitResult<CreativeDocument>>;
  };
  assets: {
    ensurePoster?(input: CreativeAssetEnsurePoster): Promise<CreativeAssetEnsurePosterResult>;
    audioSummary?(input: CreativeAssetAudioSummary): Promise<CreativeAssetAudioSummaryResult>;
    list(input: CreativeProjectRef & { includeArchived?: boolean }): Promise<CreativeAsset[]>;
    inspect(input: CreativeProjectRef & { assetId: string }): Promise<CreativeAssetInspect>;
    register(input: CreativeAssetRegister): Promise<CreativeCommitResult<CreativeAsset>>;
    select(input: CreativeAssetSelect): Promise<CreativeCommitResult<CreativeAsset>>;
    rename(
      input: CreativeAssetEdit & { title: string }
    ): Promise<CreativeCommitResult<CreativeAsset>>;
    archive(input: CreativeAssetEdit): Promise<CreativeCommitResult<CreativeAsset>>;
  };
  jobs: {
    list(input: CreativeProjectRef): Promise<CreativeJob[]>;
    get(input: CreativeProjectRef & { jobId: string }): Promise<CreativeJob>;
    /** Persists a production request; does not itself start a provider or imply completion. */
    request(input: CreativeJobRequest): Promise<CreativeCommitResult<CreativeJob>>;
    cancelRequest(input: CreativeJobCancelRequest): Promise<CreativeCommitResult<CreativeJob>>;
    /** Cancel unadmitted generation jobs; admitted jobs retain cancellation uncertainty. */
    cancelBatch?(
      input: CreativeMutation & { jobIds: string[] }
    ): Promise<CreativeCommitResult<CreativeJob[]>>;
  };
  onChanged(callback: (event: CreativeProjectChanged) => void): () => void;
}
