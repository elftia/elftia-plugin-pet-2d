import type {
  CreativeTimelineAssetRef,
  CreativeTimelineReplacePlan,
  CreativeTimelineReplaceRequest,
} from './creative-timeline';
import type { CreativeMediaFacts } from './creative-media-facts';

export type { CreativeMediaFacts } from './creative-media-facts';

export interface CreativeTimelineReplacementPreview {
  planId: string;
  corePlan: CreativeTimelineReplacePlan;
  executionHash: string;
  targetId: string;
  projectId: string;
  sceneId: string;
  expectedRocutRevision: number;
  locationRevision: number;
  nativeAssetId: string;
  mediaKind: 'image' | 'audio' | 'video';
  targetBytes: number;
  clipIds: string[];
  /** Actual native asset metadata; absent fields stay unverified, not compatibility approval. */
  mediaCompatibility?: {
    source: 'native-snapshot';
    target: {
      nativeAssetId: string;
      width?: number;
      height?: number;
      hasAudio?: boolean;
      mediaFacts?: CreativeMediaFacts;
    };
    clips: Array<{
      clipId: string;
      previous: {
        nativeAssetId: string;
        width?: number;
        height?: number;
        hasAudio?: boolean;
        mediaFacts?: CreativeMediaFacts;
      };
    }>;
  };
  /** Native metadata only, for duration/crop risk hints; not replacement authorization. */
  timing?: {
    source: 'native-snapshot';
    timebase: 120000;
    targetDurationTicks?: number;
    clips: Array<{
      clipId: string;
      durationTicks: number;
      trimStartTicks: number;
      trimEndTicks: number;
    }>;
  };
}
/** Creator Main only. Tokens never belong to renderer DTOs or agent execution catalogs. */
export interface HostCreativeTimelineReplacementLike {
  /** Record-only reconciliation. Never reissues confirmation or native execution. */
  recoverReplace?(input: {
    creativeProjectId: string;
    expectedRevision: number;
    operationId: string;
    sourceSessionId: string;
    originalOperationId: string;
  }): Promise<
    | {
        status: 'recorded-artifact-match';
        originalOperationId: string;
        intentId: string;
        projectRevision: number;
      }
    | { status: 'prepared-only'; reason: string }
  >;
  prepareReplace?(
    input: CreativeTimelineReplaceRequest & { sourceSessionId: string; targetId: string }
  ): Promise<
    | { status: 'prepared'; plan: CreativeTimelineReplacementPreview }
    | { status: 'prepared-only'; reason: string }
  >;
  requestReplaceConfirmation?(input: {
    planId: string;
  }): Promise<
    | { status: 'approved'; confirmationToken: string; expiresAt: number }
    | { status: 'cancelled' | 'prepared-only'; reason: string }
  >;
  executeConfirmedReplace?(input: {
    planId: string;
    confirmationToken: string;
  }): Promise<
    | { status: 'recorded'; projectRevision: number }
    | { status: 'needs-reconciliation'; intentId: string; reason: string }
  >;
  /** Reads original durable evidence only. Never authorizes, dispatches or registers a replacement. */
  readReplaceRecovery?(input: {
    creativeProjectId: string;
    sourceSessionId: string;
    originalOperationId: string;
  }): Promise<{
    status: 'recorded' | 'needs-reconciliation';
    intentId: string;
    artifactMatch: boolean | null;
    reason?: string;
  }>;
}
