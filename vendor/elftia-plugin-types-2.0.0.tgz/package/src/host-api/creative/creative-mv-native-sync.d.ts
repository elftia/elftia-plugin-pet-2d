import type { CreativeMvScope } from './creative-mv';

export type CreativeMvNativeSyncInput = CreativeMvScope & {
  timelineId: string;
  action?: 'inspect' | 'adopt';
  expectedNativeRevision?: number;
  expectedTimelineRevision?: number;
  resolutions?: Array<{ nodeId: string; field: string; choice: 'author' | 'native' }>;
  adoptClipIds?: string[];
};
export interface CreativeMvNativeSyncResult {
  status: string;
  reason?: string;
  nativeRevision?: number;
  timelineRevision?: number;
  preservedNativeEdits?: Array<{ nodeId: string; nativeObjectId: string }>;
  changes?: Array<{
    nodeId: string;
    field: string;
    before: unknown;
    author: unknown;
    native: unknown;
    conflict: boolean;
  }>;
  conflicts?: Array<{ nodeId: string; field: string }>;
  nativeOwned?: Array<{
    id: string;
    trackId: string;
    assetId?: unknown;
    range: { startTick: unknown; durationTicks: unknown };
  }>;
}
